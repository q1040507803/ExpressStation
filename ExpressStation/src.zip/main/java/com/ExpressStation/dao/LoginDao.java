package com.ExpressStation.dao;

import com.ExpressStation.bean.User;

public interface LoginDao {
    User logindao(User u);
}

package com.ExpressStation.service;

import com.ExpressStation.bean.User;

public interface LoginService {
    User loginService(User u);
}
